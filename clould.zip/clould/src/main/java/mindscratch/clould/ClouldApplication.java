package mindscratch.clould;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClouldApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClouldApplication.class, args);
	}

}
